from enum import Enum

class Gamestate(Enum):
    MENU = 1
    RUNNING = 2
    GAME_OVER = 3
    SCOREBOARD = 4