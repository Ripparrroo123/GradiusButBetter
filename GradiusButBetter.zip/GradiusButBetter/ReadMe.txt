Basic controls:
Use W, A, S, and D or the arrow keys to move.
Use the Spacebar to shoot.

Special Moves:
Rapidly tap the Spacebar to shoot slightly stronger bullets. These can be shot as fast as you tap, so they can be very powerful if you're quick.
Hold the Spacebar until the player becomes red, then release the Spacebar to fire a large, very powerful shot.

Your goal:
Survive as long as you can and earn points by destroying enemies and bosses.

Hotkeys:

-Menu
    ESC - Shut down the game
    M - Mute the audio
    Enter - Start the game

-Playing
    ESC - Go back to the menu
    M - Mute the audio
    R - Reset the game

-Scoreboard 
    ESC - Go back to the menu
    M - Mute the audio
    Enter - Start the game

Credits:
Lead game design, character design, programming - Emil Jansson
Lead UI design, lead sound design, programming - Gabriel Mattsson

Sound effects created using Leshylabs
https://www.leshylabs.com/apps/sfMaker/

Special thanks - Jesus